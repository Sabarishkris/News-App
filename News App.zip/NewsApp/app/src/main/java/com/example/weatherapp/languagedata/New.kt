package com.example.weatherapp.languagedata

data class New(
    val description: String,
    val id: String,
    val image: String,
    val published_date: String,
    val title: String,
    val url: String
)