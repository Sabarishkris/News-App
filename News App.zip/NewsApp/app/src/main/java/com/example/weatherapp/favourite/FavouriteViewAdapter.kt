package com.example.weatherapp.favourite

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R
import com.example.weatherapp.news.SetClick

class FavouriteViewAdapter(private var list: List<com.example.weatherapp.database.Article>,private var setClick: SetClick) :
    RecyclerView.Adapter<FavouriteViewAdapter.ViewHolder>() {

    class ViewHolder(view: View,setClick: SetClick) : RecyclerView.ViewHolder(view) {
        init {
            val dustbin=view.findViewById<ImageView>(R.id.dust_bin)
            itemView.setOnClickListener { setClick.itemClicked(adapterPosition) }
            dustbin.setOnClickListener { setClick.dustBin(adapterPosition) }
        }
        val image: ImageView = view.findViewById(R.id.news_image)
        val title: TextView = view.findViewById(R.id.news_heading)
        val subtitle: TextView = view.findViewById(R.id.sub_title)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.offline_feed_layout, parent, false)
        return ViewHolder(view,setClick)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val article: com.example.weatherapp.database.Article = list[position]
        holder.title.text = article.title
        holder.subtitle.text = article.description
    }

    @SuppressLint("NotifyDataSetChanged")
    fun clearItem() {
        list= emptyList()
        notifyDataSetChanged()
    }
}
