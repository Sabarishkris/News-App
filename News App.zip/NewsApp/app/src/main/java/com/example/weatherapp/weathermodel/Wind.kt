package com.example.weatherapp.model

data class Wind(
    val deg: Int,
    val speed: Double
)