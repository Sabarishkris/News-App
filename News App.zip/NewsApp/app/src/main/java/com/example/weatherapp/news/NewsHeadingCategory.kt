package com.example.weatherapp.news

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.databinding.HeaderLayoutBinding
import kotlinx.coroutines.currentCoroutineContext
import java.util.Locale
import kotlin.coroutines.coroutineContext

class NewsHeadingCategory(private val categories: List<String>,
                          private val clickOnCategory: ClickOnCategory) :
    RecyclerView.Adapter<NewsHeadingCategory.CategoryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = HeaderLayoutBinding.inflate(layoutInflater, parent, false)
        return CategoryViewHolder(binding, clickOnCategory)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        holder.bind(categories[position])

    }

    override fun getItemCount() = categories.size

    class CategoryViewHolder(private val binding: HeaderLayoutBinding,clickOnCategory: ClickOnCategory) :
        RecyclerView.ViewHolder(binding.root){
            init {
                itemView.setOnClickListener {
                    val categorytemp=binding.categoryHeading.text.toString()
                    var ans=categorytemp.substring(2).toLowerCase(Locale.ROOT)
                    clickOnCategory.clickONListenerCategory(ans)
                Log.i("clicked","Clicked")}
            }
        val s: String = "# "
        fun bind(category: String) {
            var temp:String=s+category
            binding.categoryHeading.text = temp
            binding.executePendingBindings()
        }
    }
    interface ClickOnCategory{
        fun clickONListenerCategory(category: String)
    }
}
