package com.example.weatherapp.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.weatherapp.data.Source

@Entity(tableName = "Article", indices = [Index(value = ["title"], unique = true)])
data class Article(
    @ColumnInfo(name = "id")
    @PrimaryKey(autoGenerate = true)
    var id: Int,
    @ColumnInfo(name = "author")
    var author: String,
    @ColumnInfo(name = "content")
    var content: String,
    @ColumnInfo(name = "description")
    var description: String,
    @ColumnInfo(name = "published")
    var publishedAt: String,
    @ColumnInfo(name = "title")
    var title: String,
    @ColumnInfo(name = "url")
    var url: String,

)


