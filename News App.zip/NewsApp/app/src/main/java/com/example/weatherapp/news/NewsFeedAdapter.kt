package com.example.weatherapp.news

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R
import com.example.weatherapp.data.Article
import com.squareup.picasso.Picasso

class NewsFeedAdapter(var list: List<Article>, private var setClick: SetClick) :
    RecyclerView.Adapter<NewsFeedAdapter.ViewHolder>() {
    class ViewHolder(view: View, setClick: SetClick) : RecyclerView.ViewHolder(view) {
        init {
            itemView.setOnClickListener {
                setClick.itemClicked(adapterPosition)
            }
        }

        val image: ImageView = view.findViewById(R.id.news_image)
        val title: TextView = view.findViewById(R.id.news_heading)
        val subtitle: TextView = view.findViewById(R.id.sub_title)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.footer_layout, parent, false)
        return ViewHolder(view, setClick)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val article: Article = list[position]
        if (article.urlToImage != "null") {
            Picasso.get().load(article.urlToImage).into(holder.image)
        } else {
            holder.image.setImageResource(R.drawable.commonnews)
        }
        holder.title.text = article.title
        holder.subtitle.text = article.description
    }
}

interface SetClick {
    fun itemClicked(position: Int)
    fun dustBin(adapterPosition: Int)
}
