package com.example.weatherapp.news

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R
import com.example.weatherapp.databinding.FragmentAppFrontPageBinding
import com.example.weatherapp.weather.WeatherModel
import com.google.android.material.navigation.NavigationView

@Suppress("DEPRECATION")
class AppFrontPageFragment : Fragment() {
    private lateinit var binding: FragmentAppFrontPageBinding
    private lateinit var viewModel: NewsFeedModel
    private lateinit var weatherModel: WeatherModel
    private var connectivityManager: ConnectivityManager? = null
    private lateinit var networkCallback: ConnectivityManager.NetworkCallback
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toggle: ActionBarDrawerToggle

    companion object {
        private const val ENTERTAINMENT_CATEGORY = "entertainment"
        private const val API_KEY = "87224693c3cf46b2afd835fb14da8474"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_app_front_page, container, false)
        viewModel = ViewModelProvider(this)[NewsFeedModel::class.java]
        weatherModel = ViewModelProvider(this)[WeatherModel::class.java]
        setupConnectivityManager()
        setupRecyclerViews()
        checkNetworkStatus()
        setupNavigationDrawer()

        binding.weather.setOnClickListener {
            weatherModel.fetchWeather("chennai", "metric", getString(R.string.api_key))
            view?.findNavController()?.navigate(R.id.action_appFrontPageFragment_to_weatherFragment)
        }
        binding.favouritemenu.setOnClickListener {
            view?.findNavController()?.navigate(R.id.action_appFrontPageFragment_to_favouriteViewFragment)
        }

        return binding.root
    }

    private fun setupRecyclerViews() {
        binding.categoryFeed.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        binding.newsFeed.layoutManager = LinearLayoutManager(requireContext())
        viewModel.initialize(requireContext(), binding.categoryFeed, binding.newsFeed)

    }

    private fun setupConnectivityManager() {
        connectivityManager = requireContext().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    private fun setupNavigationDrawer() {
        (activity as AppCompatActivity).setSupportActionBar(binding.appToolbar)
        drawerLayout = binding.drawLayout
        toggle = ActionBarDrawerToggle(
            activity,
            drawerLayout,
            binding.appToolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        appBarConfiguration = AppBarConfiguration(setOf(R.id.appFrontPageFragment), drawerLayout)

        binding.navView.setNavigationItemSelectedListener { item ->
            handleNavigation(item.itemId)
            true
        }
    }

    private fun handleNavigation(itemId: Int) {
        val direction = when (itemId) {
            R.id.tamil -> "tamil"
            R.id.arabic -> "arabic"
            R.id.danish -> "danish"
            R.id.french -> "french"
            R.id.korean -> "korean"
            else -> return
        }
        viewModel.sendDirection(direction)
        drawerLayout.closeDrawers()
    }

    private fun checkNetworkStatus() {
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val networkCapabilities = connectivityManager?.getNetworkCapabilities(network)
                val isWifi = networkCapabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
                val isMobile = networkCapabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true

                if (isWifi || isMobile) {
                    Handler(Looper.getMainLooper()).post {
                        binding.fullLayout.isVisible = true
                        binding.noInternetLayout.isInvisible = true
                        viewModel.fetchNews(ENTERTAINMENT_CATEGORY, API_KEY)
                        viewModel.setFeed(binding.newsFeed)
                        viewModel.setHeader(binding.categoryFeed)
                    }
                } else {
                    Handler(Looper.getMainLooper()).post {
                        binding.fullLayout.isInvisible = true
                        binding.noInternetLayout.isVisible = true
                    }
                }
            }

            override fun onLost(network: Network) {
                Handler(Looper.getMainLooper()).post {
                    binding.fullLayout.isInvisible = true
                    binding.noInternetLayout.isVisible = true
                    Toast.makeText(requireContext(), "Network connection lost", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val networkRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()

        connectivityManager?.registerNetworkCallback(networkRequest, networkCallback)
    }

    override fun onDestroy() {
        super.onDestroy()
        connectivityManager?.unregisterNetworkCallback(networkCallback)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
//            R.id.Add_New ->{
////                viewModel.addNewNews()
//                Toast.makeText(requireContext(),"New News Added successfully",Toast.LENGTH_SHORT).show()
//                true
//            }
            R.id.favouritemenu -> {
                view?.findNavController()?.navigate(R.id.action_appFrontPageFragment_to_favouriteViewFragment)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

