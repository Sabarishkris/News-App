package com.example.weatherapp


import android.os.Bundle

import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

import androidx.databinding.DataBindingUtil

import androidx.lifecycle.ViewModelProvider

import com.example.weatherapp.databinding.ActivityMainBinding

import com.example.weatherapp.weather.WeatherModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var weatherModel: WeatherModel
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        weatherModel = ViewModelProvider(this).get(WeatherModel::class.java)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        requestLocationPermission()

        // val navController=findNavController(R.id.fragmentContainerView)
        // appBarConfiguration=AppBarConfiguration(navController.graph,drawerLayout)
        // NavigationUI.setupActionBarWithNavController(this,navController,appBarConfiguration)
        // NavigationUI.setupWithNavController(binding.navView,navController)

    }


//    override fun onSupportNavigateUp(): Boolean {
//        val navController=findNavController(R.id.fragmentContainerView)
//        return NavigationUI.navigateUp(navController,appBarConfiguration)||super.onSupportNavigateUp()
//    }

    fun requestLocationPermission() {
        MainActivity.LOCATION_PERMISSION_REQUEST_CODE
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            MainActivity.LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    companion object {
        const val LOCATION_PERMISSION_REQUEST_CODE = 1
    }
}