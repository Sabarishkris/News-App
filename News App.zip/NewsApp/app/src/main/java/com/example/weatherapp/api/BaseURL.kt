package com.example.weatherapp.api

object BaseURL {
    var base:String="https://newsapi.org/v2/"
}