import android.annotation.SuppressLint
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.R
import com.example.weatherapp.database.Article
import com.example.weatherapp.favourite.FavouriteViewAdapter
import com.example.weatherapp.news.SetClick
import com.example.weatherapp.offline.FavouriteViewFragmentDirections
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class Favouritemodel : ViewModel(), SetClick {
    private lateinit var repository: Repository
    val list: LiveData<List<Article>> get() = repository.list

    @SuppressLint("StaticFieldLeak")
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FavouriteViewAdapter

    fun storeData(
        applicationContext: Context,
        title: String,
        author: String,
        description: String,
        url: String,
        published: String,
        content: String,
        urlToImage: String
    ) {
        repository = Repository(applicationContext)
        repository.storeData(title, author, description, url, published, content)

    }

    fun initialize(applicationContext: Context, recyclerView: RecyclerView) {
        repository = Repository(applicationContext)
        this.recyclerView = recyclerView
        fetchAndSetData()
    }

    private fun fetchAndSetData() {
        repository.getList()
        list.observeForever {
            this.adapter = FavouriteViewAdapter(it, this)
            recyclerView.adapter = adapter
        }
    }

    override fun itemClicked(position: Int) {
        var article = list.value
        var articles: Article? = article?.get(position)
        var title = if (articles?.title == null) null else articles.title
        var desc = articles?.description
        var content = articles?.content
        var author = articles?.author
        var published = articles?.publishedAt
        var url = articles?.url
        val action =
            FavouriteViewFragmentDirections.actionFavouriteViewFragmentToOfflineViewfragment(
                title.toString(),
                desc.toString(),
                content.toString(),
                author.toString(),
                published.toString(),
                url.toString(),
            )

        recyclerView.findNavController().navigate(action)
    }

    override fun dustBin(adapterPosition: Int) {
        var newsValue=list.value
        var news: Article? =newsValue?.get(adapterPosition)
        repository.deleteItem(news)
        viewModelScope.launch {
            withContext(Dispatchers.Main) {
                adapter.clearItem()
                fetchAndSetData()
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun deleteAll() {
        repository.deleteAll()
        viewModelScope.launch {
            withContext(Dispatchers.Main) {
                adapter.clearItem()
            }

        }
    }
}
