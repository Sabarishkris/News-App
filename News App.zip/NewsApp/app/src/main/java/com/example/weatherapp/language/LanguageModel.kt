package com.example.weatherapp.language

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.weatherapp.data.Article
import com.example.weatherapp.languagedata.New
import com.example.weatherapp.news.AppFrontPageFragmentDirections
import kotlinx.coroutines.launch

class LanguageModel : ViewModel(), SetClick {

    @SuppressLint("StaticFieldLeak")
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: LanguageAdapter
    private lateinit var repository: LanguageRepository
    private val _news = MutableLiveData<List<New>>()
    val news: LiveData<List<New>> get() = _news

    fun initialize(
        applicationContext: Context,
        recyclerView: RecyclerView,
        category: String
    ) {
        this.recyclerView = recyclerView
        this.repository = LanguageRepository(applicationContext)
        fetchNews("ML6gfRxMCMtUYTNcBqiTVZLDHq18tO", category)
        setFeed(recyclerView)
        Log.d("category", "initialize: ${category}")
    }

    private fun fetchNews(apiKey: String, category: String) {
        viewModelScope.launch {
            try {
                val response = repository.getlist(apiKey, category)
                if (response.isSuccessful) {
                    val articles = response.body()?.News ?: emptyList()
                    Log.e("LanguageModel", "Done fetching news")
                    _news.postValue(articles)
                } else {
                    Log.e("LanguageModel", "Error fetching news: ${response.message()}")
                    _news.postValue(emptyList())
                }
            } catch (e: Exception) {
                Log.e("LanguageModel", "Exception fetching news", e)
                _news.postValue(emptyList())
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setFeed(recyclerView: RecyclerView) {
        _news.observeForever { news ->
            if (news != null) {
                adapter = LanguageAdapter(news, this)
                Log.e("LanguageModel", "Adapter entered")
                recyclerView.adapter = adapter
                adapter.notifyDataSetChanged()
            } else {
                Log.e("LanguageModel", "No news to display")
            }
        }
    }

    override fun itemClicked(position: Int) {
        var news = _news.value
        var new: New? = news?.get(position)
        var title = new?.title
        var desc = new?.description
        var content = ""
        var image = new?.image
        var author = ""
        var published = new?.published_date
        var url = new?.url
        var urlToImage = ""
        val action = LanguageFragmentDirections.actionLanguageFragmentToFavouriteFragment(
            title.toString(),
            desc.toString(),
            content.toString(),
            image.toString(),
            author.toString(),
            published.toString(),
            url.toString(),
            urlToImage.toString()
        )
        recyclerView.findNavController().navigate(action)
    }
}
